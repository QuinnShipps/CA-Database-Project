import { Component, OnInit } from '@angular/core';
import {FormGroup, FormControl, Validators, FormsModule} from '@angular/forms';
import {CommonService} from './common.service';

import {Http,Response,Headers,RequestOptions} from '@angular/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  constructor(private newService : CommonService){}
  Repdata;

  ngOnInit() {
    this.newService.getAnimal().subscribe(data => this.Repdata = data)
  }

  updateText() {
    var found = this.Repdata.filter(function(item) { return item.name === (<HTMLInputElement>document.getElementById('select_animal')).value}).description;
    document.getElementById('description_box').innerHTML = found[0];
  }

  edit = function(kk) {
    this.id = kk._id;
    this.name = kk.name;
    this.description = kk.description;
  }
}
